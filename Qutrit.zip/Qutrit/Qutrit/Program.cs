﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Qutrit.Function;
using Qutrit.Model;
using Qutrit.Operation;

namespace Qutrit
{
    class Program
    {
        static void Main(string[] args)
        {

            #region  Lib

            Translate_Tenary translate_Tenary = new Translate_Tenary();
            Translate_Decimal translate_Decimal = new Translate_Decimal();
            Formules formules = new Formules();

            Initail initail = new Initail();
            Observe observe = new Observe();
            Update update = new Update();
            Fitness fitness = new Fitness();
            #endregion

            int PopulationSize = 10;

            var QuantumPopulation = initail.Initial_QuantumPopulation(PopulationSize);
            QuantumPopulation = observe.Observe_QuantumPopulation(QuantumPopulation, -1);
            int BestChromosomeIndex = fitness.Find_Best_Index(QuantumPopulation);

            int RunCounter = 0;
            while (QuantumPopulation[BestChromosomeIndex].classic.Fitness != 3)
            {
                RunCounter++;

                QuantumPopulation = observe.Observe_QuantumPopulation(QuantumPopulation, BestChromosomeIndex);
                QuantumPopulation = update.Update_QuantumPopulation(QuantumPopulation, BestChromosomeIndex);

                int BestChromosomeIndex_Temp = fitness.Find_Best_Index(QuantumPopulation);
                if (QuantumPopulation[BestChromosomeIndex_Temp].classic.Fitness < QuantumPopulation[BestChromosomeIndex].classic.Fitness)
                    BestChromosomeIndex = BestChromosomeIndex_Temp;

                if(RunCounter>1000)
                {
                    RunCounter = 0;
                    var BestTemp = QuantumPopulation[BestChromosomeIndex];
                    QuantumPopulation = initail.Initial_QuantumPopulation(PopulationSize - 1);
                    QuantumPopulation.Add(BestTemp);
                    BestChromosomeIndex = PopulationSize - 1;
                }

            }


            Console.ReadKey();

        }
    }
}

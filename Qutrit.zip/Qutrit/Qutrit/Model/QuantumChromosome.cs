﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Model
{
    class QuantumChromosome
    {
        public List<Qutrit> Qutrits { get; set; }

        public ClassicChromosome classic { get; set; }
    }
}

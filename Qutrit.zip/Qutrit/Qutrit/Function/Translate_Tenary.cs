﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Function
{
    class Translate_Tenary
    {
        private static double BaseNumber = 3;

        public string Translate_Decimal_To_Tenary(double DecimalNumber)
        {
            int sign = (DecimalNumber > 0 ? 0 : 1);
            DecimalNumber = Math.Abs(DecimalNumber);

            string Output = "";
            Output = Translate_Integer_Of_Decimal_To_Tenary(Math.Floor(DecimalNumber));
            Output += Translate_Float_Of_Decimal_To_Tenary(DecimalNumber - Math.Floor(DecimalNumber));
            Output = Convert_To_IEEE_Standard(Output, sign);
            return Output;
        }


        private string Translate_Integer_Of_Decimal_To_Tenary(double DecimalNumber)
        {
            string Output = "";
            do {
                Output = (DecimalNumber % BaseNumber) + Output;
                DecimalNumber = Math.Floor(DecimalNumber / BaseNumber);
            }
            while (DecimalNumber != 0);

            if (string.IsNullOrEmpty(Output))
                return "0";
            else
                return Output;
        }

        private string Translate_Float_Of_Decimal_To_Tenary(double DecimalNumber)
        {
            int Counter = 0;
            string Output = "";
            do
            {
                Counter++;
                DecimalNumber = DecimalNumber * BaseNumber;
                Output = Output+ Math.Floor(DecimalNumber);
                DecimalNumber = DecimalNumber - Math.Floor(DecimalNumber);
            }
            while (DecimalNumber != 0 && Counter<23);

            if(string.IsNullOrEmpty(Output))
                return ".0";
            else
                return "."+Output;

        }

        private string Convert_To_IEEE_Standard(string Input,int sing)
        {
            int Shift_Exp = 0;

            double Input_temp = double.Parse(Input);

            while (Math.Floor(Input_temp) !=1)
            {
                if(Input_temp < 1)
                {
                    Shift_Exp--;
                    Input_temp = Input_temp * 10;
                }
                else
                {
                    Shift_Exp++;
                    Input_temp = Input_temp / 10;
                }
            }

            string Exp = Translate_Integer_Of_Decimal_To_Tenary(Shift_Exp + 2176);
            string Float = Input.ToString().Substring(2);
            
            for (int i = 0; i < 32-Float.Length; i++)
            {
                Float += "0";
            }

            for (int i = 0; i < 8 - Exp.Length; i++)
            {
                Exp = "0" + Exp;
            }

            return sing + Exp + Float;
        }


    }
}

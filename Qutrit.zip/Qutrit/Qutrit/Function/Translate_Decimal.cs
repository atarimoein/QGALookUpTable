﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Function
{
    class Translate_Decimal
    {
        private static double BaseNumber = 3;
        private Random random = new Random();

        public double Translate_Tenary_To_Decimal(string TenerayNumber)
        {
            int Sign = int.Parse(TenerayNumber.Substring(0, 1));
            string fraction = TenerayNumber.Substring(1);

            double DecimalNumber = Translate_Tenary_To_Decimal_Interger(Int64.Parse(fraction));
            double randNumber = random.NextDouble() * 3 ;
            if (randNumber < Sign)
                DecimalNumber = -1 * DecimalNumber;

            return DecimalNumber;
        }


        private double Translate_Tenary_To_Decimal_Interger(Int64 Input)
        {
            int Counter = 0;
            double Sum = 0;
            while (Input>0)
            {
                Sum += (Input % 10) * Math.Pow(BaseNumber, Counter);
                Input = Input / 10;
                Counter++;
            }
            return Sum;
        }

    }
}

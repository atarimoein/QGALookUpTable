﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Function
{
    class Translate_Decimal
    {
        private static double BaseNumber = 3;
        private Random random = new Random();

        public double Translate_Tenary_To_Decimal(string TenerayNumber)
        {
            //int Sign = int.Parse(TenerayNumber.Substring(0, 1));
            //int exponent = int.Parse(TenerayNumber.Substring(1, 8));
            //string fraction = TenerayNumber.Substring(9);

            int Sign = int.Parse(TenerayNumber.Substring(0, 1));
            string fraction = TenerayNumber.Substring(1);


            //double exp = (Translate_Tenary_To_Decimal_Interger(exponent) / 2) - 2.5;


            //double fraction_Left = 0, fraction_Right=0;



            //if (exp<0)
            //{
            //    fraction = "1" + fraction;
            //    for (int i = 0; i < exp-1; i++)
            //    {
            //        fraction = "0" + fraction;
            //    }

            //    fraction_Right = double.Parse("0." + fraction);
            //    fraction_Left = 0;
            //}
            //else
            //{
            //    string tempLeft = "1"+fraction.Substring(0, int.Parse(Math.Floor(exp) + ""));
            //    string tempRight = fraction.Substring(int.Parse(Math.Floor(exp) + ""));

            //    fraction_Right = double.Parse("0." + tempRight);
            //    fraction_Left = double.Parse(tempLeft);
            //}

            //double DecimalNumber = Math.Pow(-1, Sign) * (Translate_Tenary_To_Decimal_Interger(Int64.Parse(Math.Floor(fraction_Left) + "")) + Translate_Tenary_To_Decimal_Float(fraction_Right));

            double DecimalNumber = Translate_Tenary_To_Decimal_Interger(Int64.Parse(fraction));
            double randNumber = random.NextDouble() * 3 ;
            if (randNumber < Sign)
                DecimalNumber = -1 * DecimalNumber;

            return DecimalNumber;
        }


        private double Translate_Tenary_To_Decimal_Interger(Int64 Input)
        {
            int Counter = 0;
            double Sum = 0;
            while (Input>0)
            {
                Sum += (Input % 10) * Math.Pow(BaseNumber, Counter);
                Input = Input / 10;
                Counter++;
            }
            return Sum;
        }

        private double Translate_Tenary_To_Decimal_Float(double Input)
        {

            int Counter = 1;
            double Sum = 0;
            while (Input != 0)
            {
                Input = Input * 10;

                if (Input >= 2)
                {
                    break;
                }
                else if (Input>=1)
                {
                    Sum += 1 / Math.Pow(BaseNumber, Counter);
                    Input = Input - 1;
                }              
                Counter++;
            }
            return Sum;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Function
{
    class Formules
    {

        public double De_Jongs_function_1(double x1, double x2)
        {
            //// Need 10 genes
            /// Global Min = 0
            double f1 = 100 * (Math.Pow(x1, 2) - Math.Pow(x2, 2)) + (1 - Math.Pow(x1, 2));
            return Math.Round(f1, 3);
        }


        public double Coldstein_Price_function_2(double x1, double x2)
        {
            //// Need 8 genes
            /// Global Min = 3

            double Part1 = (
                            1 +
                            Math.Pow((x1 + x2 + 1), 2) *
                            (
                                19 -
                                (14 * x1) +
                                (3 * Math.Pow(x1, 2)) -
                                (14 * x2) +
                                (6 * x1 * x2) +
                                (3 * Math.Pow(x2, 2))
                             )
                        );

            double Part2 = (
                            30 +
                            Math.Pow(((2 * x1) - (3 * x2)), 2) *
                            (
                                18 -
                                (32 * x1) +
                                (12 * Math.Pow(x1, 2)) +
                                (48 * x2) -
                                (36 * x1 * x2) +
                                (27 * Math.Pow(x2, 2))
                             )
                            );



            double f2 = Part1 * Part2;
            return Math.Round(f2, 3);
        }

        public double Schaffer_function_3(double x1, double x2)
        {
            //// Need 16 genes
            /// Global Min = 0

            double Part1 = Math.Pow(
                            Math.Pow(x1, 2) + Math.Pow(x2, 2),
                            2
                           ) - 0.5;

            double Part2 = 1.0 + (
                            0.001 * (Math.Pow(x1, 2) + Math.Pow(x2, 2))
                            );



            double f3 = 0.5 + (Part1 / Math.Pow(Part2, 2));

            return Math.Round(f3, 3);
        }

        public double Monopole_and_Six_Peak_Camelback_function_4(double x1)
        {
            //// Need 16 genes
            /// Global Min = 0


            x1 = Math.Round(x1, 4);


            double f4 = 10 + (
                    Math.Sin(1/x1) / 
                    (   
                        0.1 + 
                        Math.Pow((x1 - 0.16),2)
                    )
                );

            f4 = Math.Round(f4, 4);

            return f4;
        }

        public double SIX_HUMP_CAMEL_fUNCTION_5(double x1, double x2)
        {
            //// Need 16 genes
            /// Global Min = 0

            double Part1 = Math.Pow(x1,2) * 
                           (
                             4 -
                             (2.1 * Math.Pow(x1,2)) +
                             ( Math.Pow(x1, 4)/3)
                             );

            double Part2 = Math.Pow(x2, 2) * (
                            -4 +
                            (4 * Math.Pow(x2, 2))
                            );



            double f5 = Part1 + (x1 * x2) + Part2;

            return Math.Round(f5, 6);
        }

    }
}

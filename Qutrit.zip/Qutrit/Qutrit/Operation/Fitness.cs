﻿using Qutrit.Function;
using Qutrit.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Operation
{
    class Fitness
    {
        Translate_Decimal translate_Decimal = new Translate_Decimal();
        Formules formules = new Formules();

        public double Calc_Function(string BinaryCode,  ref QuantumChromosome Qchromosome)
        {
            //double x1 = translate_Decimal.Translate_Tenary_To_Decimal(BinaryCode) / 100000;

            string BinaryCode_X1 = BinaryCode.Substring(0, BinaryCode.Length / 2);
            string BinaryCode_X2 = BinaryCode.Substring(BinaryCode.Length / 2);

            double x1 = translate_Decimal.Translate_Tenary_To_Decimal(BinaryCode_X1) / 10;
            double x2 = translate_Decimal.Translate_Tenary_To_Decimal(BinaryCode_X2) / 10;

            double Result = formules.Coldstein_Price_function_2(x1,x2);
            return Result;
        }

        public int Find_Best_Index(List<QuantumChromosome> quantumChromosomes)
        {
            int Result = 0;
            foreach (var QChromosome in quantumChromosomes.Skip(1).ToList())
            {
                if (QChromosome.classic.Fitness < quantumChromosomes[Result].classic.Fitness)
                    Result = quantumChromosomes.IndexOf(QChromosome);
            }
            return Result;
        }

    }
}

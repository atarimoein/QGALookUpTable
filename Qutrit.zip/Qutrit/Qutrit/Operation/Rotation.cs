﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Operation
{
    class Rotation
    {
        Random random = new Random();

        #region Qutrit Rotation

        public Qutrit.Model.Qutrit Increase_Alpha_Qutrit(Qutrit.Model.Qutrit quantumGene, double Teta)
        {


            if (quantumGene.Alpha > 0 && quantumGene.Beta >= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Alpha > 0 && quantumGene.Beta >= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Alpha > 0 && quantumGene.Beta <= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Alpha > 0 && quantumGene.Beta <= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }

            else if (quantumGene.Alpha < 0 && quantumGene.Beta >= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Alpha < 0 && quantumGene.Beta >= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Alpha < 0 && quantumGene.Beta <= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Alpha < 0 && quantumGene.Beta <= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_Y(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }

            else
            {
                return quantumGene;
            }

        }

        public Qutrit.Model.Qutrit Increase_Betta_Qutrit(Qutrit.Model.Qutrit quantumGene, double Teta)
        {


            if (quantumGene.Beta > 0 && quantumGene.Alpha >= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Beta > 0 && quantumGene.Alpha >= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Beta > 0 && quantumGene.Alpha <= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Beta > 0 && quantumGene.Alpha <= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }

            else if (quantumGene.Beta < 0 && quantumGene.Alpha >= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Beta < 0 && quantumGene.Alpha >= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Beta < 0 && quantumGene.Alpha <= 0 && quantumGene.Gamma >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }
            else if (quantumGene.Beta < 0 && quantumGene.Alpha <= 0 && quantumGene.Gamma <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Z(quantumGene, Teta);
                }
            }

            else
            {
                return quantumGene;
            }

        }

        public Qutrit.Model.Qutrit Increase_Gamma_Qutrit(Qutrit.Model.Qutrit quantumGene, double Teta)
        {


            if (quantumGene.Gamma > 0 && quantumGene.Alpha >= 0 && quantumGene.Beta >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Gamma > 0 && quantumGene.Alpha >= 0 && quantumGene.Beta <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Gamma > 0 && quantumGene.Alpha <= 0 && quantumGene.Beta >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Y(quantumGene, Teta);
                }
            }
            else if (quantumGene.Gamma > 0 && quantumGene.Alpha <= 0 && quantumGene.Beta <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Y(quantumGene, Teta);
                }
            }

            else if (quantumGene.Gamma < 0 && quantumGene.Alpha >= 0 && quantumGene.Beta >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Y(quantumGene, Teta);
                }
            }
            else if (quantumGene.Gamma < 0 && quantumGene.Alpha >= 0 && quantumGene.Beta <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Y(quantumGene, Teta);
                }
            }
            else if (quantumGene.Gamma < 0 && quantumGene.Alpha <= 0 && quantumGene.Beta >= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, (-1 * Teta));
                }
                else
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
            }
            else if (quantumGene.Gamma < 0 && quantumGene.Alpha <= 0 && quantumGene.Beta <= 0)
            {
                if (random.Next(100) >= 50)
                {
                    return Rotation_X(quantumGene, Teta);
                }
                else
                {
                    return Rotation_Y(quantumGene, (-1 * Teta));
                }
            }

            else
            {
                return quantumGene;
            }

        }


        public Qutrit.Model.Qutrit Rotation_X(Qutrit.Model.Qutrit quantumGene, double Teta)
        {
            Qutrit.Model.Qutrit outGen = new Qutrit.Model.Qutrit();
            outGen.Alpha = quantumGene.Alpha;
            outGen.Beta = (Math.Cos(Teta) * quantumGene.Beta) + ((-1 * Math.Sin(Teta)) * quantumGene.Gamma);
            outGen.Gamma = (Math.Sin(Teta) * quantumGene.Beta) + (Math.Cos(Teta) * quantumGene.Gamma);
            return outGen;
        }

        public Qutrit.Model.Qutrit Rotation_Y(Qutrit.Model.Qutrit quantumGene, double Teta)
        {
            Qutrit.Model.Qutrit outGen = new Qutrit.Model.Qutrit();
            outGen.Alpha = (Math.Cos(Teta) * quantumGene.Alpha) + (Math.Sin(Teta) * quantumGene.Gamma);
            outGen.Beta = quantumGene.Beta;
            outGen.Gamma = ((-1 * Math.Sin(Teta)) * quantumGene.Alpha) + (Math.Cos(Teta) * quantumGene.Gamma);
            return outGen;
        }

        public Qutrit.Model.Qutrit Rotation_Z(Qutrit.Model.Qutrit quantumGene, double Teta)
        {
            Qutrit.Model.Qutrit outGen = new Qutrit.Model.Qutrit();
            outGen.Alpha = (Math.Cos(Teta) * quantumGene.Alpha) + ((-1 * Math.Sin(Teta)) * quantumGene.Beta);
            outGen.Beta = (Math.Sin(Teta) * quantumGene.Alpha) + (Math.Cos(Teta) * quantumGene.Beta);
            outGen.Gamma = quantumGene.Gamma;
            return outGen;
        }


        #endregion

    }
}

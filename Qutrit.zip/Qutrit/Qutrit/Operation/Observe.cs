﻿using Qutrit.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Operation
{
    class Observe
    {
        Random random = new Random();
        Fitness fitness = new Fitness();

        public List<QuantumChromosome> Observe_QuantumPopulation(List<QuantumChromosome> quantumChromosomes, int BestIndex)
        {

            for (int QIndex = 0; QIndex < quantumChromosomes.Count; QIndex++)
            {
                if (BestIndex != QIndex)
                {
                    var tempQuantumChromosome = quantumChromosomes[QIndex];
                    var tempClassicChromosome = Observe_QuantumPopulation_Co(ref tempQuantumChromosome);
                    tempQuantumChromosome.classic = tempClassicChromosome;
                    quantumChromosomes[QIndex] = tempQuantumChromosome;
                }
            }

            return quantumChromosomes;
        }

        private ClassicChromosome Observe_QuantumPopulation_Co(ref QuantumChromosome Qchromosome)
        {

            var tempClassicChromosome = new ClassicChromosome();

            for (int i = 0; i < Qchromosome.Qutrits.Count; i++)
            {
                double RndNumber = random.NextDouble();
                if (Math.Pow(Qchromosome.Qutrits[i].Alpha, 2) > RndNumber)
                    tempClassicChromosome.BinaryCode += "0";
                else if ((Math.Pow(Qchromosome.Qutrits[i].Alpha, 2) + Math.Pow(Qchromosome.Qutrits[i].Beta, 2)) > RndNumber)
                    tempClassicChromosome.BinaryCode += "1";
                else
                    tempClassicChromosome.BinaryCode += "2";
            }
            tempClassicChromosome.Fitness = fitness.Calc_Function(tempClassicChromosome.BinaryCode, ref Qchromosome);

            return tempClassicChromosome;
        }

    }
}

﻿using Qutrit.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Operation
{
    class Initail
    {
        Random random = new Random();

        public List<QuantumChromosome> Initial_QuantumPopulation(int PopulationSize)
        {
            var Initaled_Population = new List<QuantumChromosome>();

            for (int j = 0; j < PopulationSize; j++)
            {

                Initaled_Population.Add(Make_Random_Chromosome(20));
            }

            return Initaled_Population;

        }

        private QuantumChromosome Make_Random_Chromosome(int Input_Length)
        {
            
            var QChromosome = new QuantumChromosome()
            {
                Qutrits = new List<Qutrit.Model.Qutrit>()
            };

            for (int i = 0; i < Input_Length; i++)
            {
                QChromosome.Qutrits.Add(Make_Random_Qtirt());
            }

            return QChromosome;
        }

        private Qutrit.Model.Qutrit Make_Random_Qtirt()
        {

            var tempQutrit = new Qutrit.Model.Qutrit();

            double OneThird = 1 / Math.Sqrt(3);

            tempQutrit.Alpha = OneThird;
            tempQutrit.Beta = OneThird;
            tempQutrit.Gamma = OneThird;

            if (random.Next(100) >= 50)
                tempQutrit.Alpha = tempQutrit.Alpha * -1;

            if (random.Next(100) >= 50)
                tempQutrit.Beta = tempQutrit.Beta * -1;

            if (random.Next(100) >= 50)
                tempQutrit.Gamma = tempQutrit.Gamma * -1;

            return tempQutrit;
        }
    }
}

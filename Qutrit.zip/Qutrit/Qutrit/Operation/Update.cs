﻿using Qutrit.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qutrit.Operation
{
    class Update
    {

        private double LookUpTable_Qutrit_Teta = Math.PI * 0.0072;

        Rotation rotation = new Rotation();

        public List<QuantumChromosome> Update_QuantumPopulation(List<QuantumChromosome> quantumChromosomes, int BestChromosomeIndex)
        {
            var BestChromosome = quantumChromosomes[BestChromosomeIndex];

            for (int ChromosomeIndex = 0; ChromosomeIndex < quantumChromosomes.Count; ChromosomeIndex++)
            {
                if (ChromosomeIndex != BestChromosomeIndex)
                {
                    bool BetterFitness = (BestChromosome.classic.Fitness > quantumChromosomes[ChromosomeIndex].classic.Fitness);

                    for (int GeneIndex = 0; GeneIndex < quantumChromosomes[0].Qutrits.Count; GeneIndex++)
                    {
                        quantumChromosomes[ChromosomeIndex].Qutrits[GeneIndex] = LookUpTable_Qutrit(
                                                quantumChromosomes[ChromosomeIndex].Qutrits[GeneIndex],
                                                quantumChromosomes[ChromosomeIndex].classic.BinaryCode[GeneIndex].ToString(),
                                                BestChromosome.classic.BinaryCode[GeneIndex].ToString(),
                                                BetterFitness);
                    }
                }
            }

            return quantumChromosomes;
        }

        private Qutrit.Model.Qutrit LookUpTable_Qutrit(Qutrit.Model.Qutrit quantumGene, string x, string b, bool BetterFitness)
        {
            if (x == "0" && b == "0" && !BetterFitness)
            {
                return quantumGene;
            }
            else if (x == "0" && b == "1" && !BetterFitness)
            {
                /// Increase Beta
                /// 
                return rotation.Increase_Betta_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "0" && b == "2" && !BetterFitness)
            {
                /// Increase Gamma
                /// 
                return rotation.Increase_Gamma_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "1" && b == "0" && !BetterFitness)
            {
                //// increase Alpha
                ///
                return rotation.Increase_Alpha_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "1" && b == "1" && !BetterFitness)
            {
                return quantumGene;
            }
            else if (x == "1" && b == "2" && !BetterFitness)
            {
                /// Increase Gamma
                /// 
                return rotation.Increase_Gamma_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "2" && b == "0" && !BetterFitness)
            {
                //// increase Alpha
                ///
                return rotation.Increase_Alpha_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "2" && b == "1" && !BetterFitness)
            {
                /// Increase Beta
                /// 
                return rotation.Increase_Betta_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "2" && b == "2" && !BetterFitness)
            {
                return quantumGene;
            }


            else if (x == "0" && b == "0" && BetterFitness)
            {
                return quantumGene;
            }
            else if (x == "0" && b == "1" && BetterFitness)
            {
                //// increase Alpha
                ///
                return rotation.Increase_Alpha_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "0" && b == "2" && BetterFitness)
            {
                //// increase Alpha
                ///
                return rotation.Increase_Alpha_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "1" && b == "0" && BetterFitness)
            {
                /// Increase Beta
                /// 
                return rotation.Increase_Betta_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "1" && b == "1" && BetterFitness)
            {
                return quantumGene;
            }
            else if (x == "1" && b == "2" && BetterFitness)
            {
                /// Increase Beta
                /// 
                return rotation.Increase_Betta_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);

            }
            else if (x == "2" && b == "0" && BetterFitness)
            {
                /// Increase Gamma
                /// 
                return rotation.Increase_Gamma_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else if (x == "2" && b == "1" && BetterFitness)
            {
                /// Increase Gamma
                /// 
                return rotation.Increase_Gamma_Qutrit(quantumGene, LookUpTable_Qutrit_Teta);
            }
            else
            {
                return quantumGene;
            }

        }


    }
}
